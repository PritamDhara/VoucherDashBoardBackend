package com.voucherservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoucherserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
