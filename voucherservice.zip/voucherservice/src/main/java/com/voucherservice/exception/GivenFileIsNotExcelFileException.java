package com.voucherservice.exception;

public class GivenFileIsNotExcelFileException extends Exception{

}
