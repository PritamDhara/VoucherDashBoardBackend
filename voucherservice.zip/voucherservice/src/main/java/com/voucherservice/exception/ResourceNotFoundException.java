package com.voucherservice.exception;

public class ResourceNotFoundException extends Exception {

	public ResourceNotFoundException(String msg)
	{
		super(msg);
	}
}
