package com.voucherservice.exception;

public class ResourceAlreadyExistException extends Exception {
	public ResourceAlreadyExistException(String msg)
	{
		super(msg);
	}
}
