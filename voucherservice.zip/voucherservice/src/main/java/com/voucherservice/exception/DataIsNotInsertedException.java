package com.voucherservice.exception;

public class DataIsNotInsertedException extends Exception {

}
