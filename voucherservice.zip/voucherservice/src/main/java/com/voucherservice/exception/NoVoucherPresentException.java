package com.voucherservice.exception;

public class NoVoucherPresentException extends Exception {

}
