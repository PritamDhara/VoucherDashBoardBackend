package com.voucherservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoucherserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoucherserviceApplication.class, args);
	}

}
